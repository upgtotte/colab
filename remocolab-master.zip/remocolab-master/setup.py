from setuptools import setup

setup(
    name = "remocolab.py",
    version = "0.1",
    py_modules = ['remocolab'],
    url = "https://github.com/demotomohiro/remocolab",
    author = "demotomohiro",
    install_requires = ["pyngrok"]
)
